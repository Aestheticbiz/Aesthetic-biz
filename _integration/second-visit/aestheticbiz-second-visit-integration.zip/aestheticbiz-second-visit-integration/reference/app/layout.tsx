import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "The Second Visit | AestheticBiz",
  description:
    "See what a stronger patient return journey could be worth—and how AestheticBiz connects the complete aesthetic revenue journey.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: [{ url: "/aestheticbiz-favicon.webp", type: "image/webp" }],
    shortcut: "/aestheticbiz-favicon.webp",
    apple: "/aestheticbiz-favicon.webp",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
