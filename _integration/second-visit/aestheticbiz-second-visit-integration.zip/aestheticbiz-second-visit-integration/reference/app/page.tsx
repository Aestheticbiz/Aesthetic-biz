"use client";

import { useMemo, useState } from "react";
import Image from "next/image";

const formatMoney = (value: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(value);

const loop = [
  ["01", "Attract", "Earn the right local attention."],
  ["02", "Build trust", "Answer the questions behind the treatment."],
  ["03", "Book", "Make the next step clear and easy."],
  ["04", "Attend", "Confirm, prepare and reduce avoidable gaps."],
  ["05", "Return", "Give every suitable patient a remembered next step."],
  ["06", "Refer", "Turn a good experience into reviews and introductions."],
];

const systemItems = [
  {
    title: "A website built around patient decisions",
    body: "Treatment pages answer real concerns, establish credibility and guide the right visitor towards a consultation.",
  },
  {
    title: "A booking journey that keeps moving",
    body: "Clear calls to action, immediate acknowledgement and visible follow-through prevent interested patients from disappearing.",
  },
  {
    title: "A return path for every suitable treatment",
    body: "Provider-approved reminders and rebooking journeys help patients remember the next step at the appropriate time.",
  },
  {
    title: "One owner scorecard",
    body: "See enquiries, response, bookings, attendance and return activity together—then improve the most expensive constraint first.",
  },
];

export default function Home() {
  const [patients, setPatients] = useState(25);
  const [visitValue, setVisitValue] = useState(500);
  const [currentReturn, setCurrentReturn] = useState(20);
  const [targetReturn, setTargetReturn] = useState(45);
  const [margin, setMargin] = useState(65);

  const calculation = useMemo(() => {
    const annualPatients = patients * 12;
    const returnRateGap = Math.max(0, targetReturn - currentReturn) / 100;
    const additionalVisits = annualPatients * returnRateGap;
    const additionalRevenue = additionalVisits * visitValue;
    const grossProfit = additionalRevenue * (margin / 100);

    return {
      additionalVisits,
      additionalRevenue,
      grossProfit,
      currentAnnualReturns: annualPatients * (currentReturn / 100),
      targetAnnualReturns: annualPatients * (targetReturn / 100),
    };
  }, [patients, visitValue, currentReturn, targetReturn, margin]);

  const scrollToCalculator = () => {
    document.getElementById("calculator")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#top" aria-label="AestheticBiz home">
          <Image
            className="brand-logo"
            src="/aestheticbiz-logo-transparent.png"
            alt="Aesthetic Biz — Aesthetic and Wellness"
            width={1456}
            height={343}
            priority
            unoptimized
          />
        </a>
        <a className="header-link" href="https://www.aestheticbiz.site/book-discovery">
          Book a Discovery Call <span aria-hidden="true">↗</span>
        </a>
      </header>

      <section className="hero section" id="top">
        <div className="hero-grid shell">
          <div className="hero-copy">
            <p className="eyebrow">For established, owner-led aesthetic practices</p>
            <h1>
              The first visit proves demand.
              <em>The second visit builds the business.</em>
            </h1>
            <p className="hero-intro">
              Most marketing stops when the appointment is booked. AestheticBiz
              connects the complete patient journey—so more of the people you
              worked hard to attract have a clear reason to return.
            </p>
            <div className="hero-actions">
              <button className="button button-primary" onClick={scrollToCalculator}>
                Calculate the second-visit opportunity
              </button>
              <a className="text-link" href="#revenue-loop">
                See the Aesthetic Revenue Loop <span aria-hidden="true">↓</span>
              </a>
            </div>
            <p className="microcopy">Uses your numbers. No inflated promises. No obligation.</p>
          </div>

          <div className="hero-visual" aria-label="The value of a patient relationship">
            <div className="journey-card first-card">
              <span>First visit</span>
              <strong>Attention becomes a patient</strong>
              <small>Important—but often expensive to earn.</small>
            </div>
            <div className="journey-line" aria-hidden="true"><span /></div>
            <div className="journey-card second-card">
              <span>Second visit</span>
              <strong>A transaction becomes a relationship</strong>
              <small>The beginning of retention, referrals and lifetime value.</small>
            </div>
          </div>
        </div>
      </section>

      <section className="section problem-section">
        <div className="shell narrow-shell">
          <p className="eyebrow">The real commercial problem</p>
          <h2>You may not need more leads first.</h2>
          <p className="lead">
            A practice can have a beautiful website, paid campaigns, a booking
            system and a capable team—and still lose value between the first
            enquiry and the next appointment.
          </p>

          <div className="cost-strip">
            <article>
              <span>Before the first visit</span>
              <h3>You pay to be found and chosen.</h3>
              <p>Brand, content, search, advertising, reviews, calls and staff time.</p>
            </article>
            <article>
              <span>After the treatment</span>
              <h3>The relationship is often left to memory.</h3>
              <p>No clear next step. No timely reminder. No visible return journey.</p>
            </article>
            <article className="accent-card">
              <span>The opportunity</span>
              <h3>Earn more from trust you already created.</h3>
              <p>Not by pushing treatment—by making good follow-through normal.</p>
            </article>
          </div>
        </div>
      </section>

      <section className="section calculator-section" id="calculator">
        <div className="shell">
          <div className="section-heading split-heading">
            <div>
              <p className="eyebrow">The second-visit calculator</p>
              <h2>What could a stronger return journey be worth?</h2>
            </div>
            <p>
              Move five sliders. The calculation uses only the figures you enter;
              it does not assume a result or invent a patient.
            </p>
          </div>

          <div className="calculator-grid">
            <div className="controls-panel">
              <Slider label="New patients per month" value={patients} min={5} max={150} step={1} display={String(patients)} onChange={setPatients} />
              <Slider label="Average visit value" value={visitValue} min={100} max={2500} step={50} display={formatMoney(visitValue)} onChange={setVisitValue} />
              <Slider label="Patients who currently return" value={currentReturn} min={0} max={80} step={1} display={`${currentReturn}%`} onChange={(value) => setCurrentReturn(Math.min(value, targetReturn))} />
              <Slider label="Return rate you want to model" value={targetReturn} min={5} max={90} step={1} display={`${targetReturn}%`} onChange={(value) => setTargetReturn(Math.max(value, currentReturn))} />
              <Slider label="Gross margin per visit" value={margin} min={20} max={90} step={1} display={`${margin}%`} onChange={setMargin} />
            </div>

            <div className="result-panel" aria-live="polite">
              <p className="result-kicker">One year, using your figures</p>
              <p className="result-label">Potential additional revenue</p>
              <strong className="result-number">{formatMoney(calculation.additionalRevenue)}</strong>
              <p className="result-explanation">
                If the share of new patients who return once moves from {currentReturn}%
                to {targetReturn}%, that represents approximately{" "}
                <b>{Math.round(calculation.additionalVisits)} additional visits</b> in a year.
              </p>

              <div className="result-metrics">
                <div><span>Gross-profit opportunity</span><strong>{formatMoney(calculation.grossProfit)}</strong></div>
                <div><span>Current annual returns</span><strong>{Math.round(calculation.currentAnnualReturns)}</strong></div>
                <div><span>Modelled annual returns</span><strong>{Math.round(calculation.targetAnnualReturns)}</strong></div>
              </div>

              <div className="calculation-note">
                <span aria-hidden="true">i</span>
                <p>
                  This is a planning estimate, not a forecast or guarantee. It models
                  one additional visit only and excludes treatment mix, capacity,
                  discounts, cancellations, tax and operating costs.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section truth-section">
        <div className="shell truth-grid">
          <div>
            <p className="eyebrow">Why the number matters</p>
            <h2>The calculator is not the promise. It reveals the missing job.</h2>
          </div>
          <div className="truth-copy">
            <p>
              Marketing usually has an owner. The treatment has an owner. But the
              journey between “that went well” and “I should book again” often belongs
              to nobody.
            </p>
            <p>
              AestheticBiz gives that journey an owner. We connect the website,
              booking path, follow-up and measurement so the practice can see where
              value is being lost—and improve the right constraint first.
            </p>
          </div>
        </div>
      </section>

      <section className="section loop-section" id="revenue-loop">
        <div className="shell">
          <div className="section-heading">
            <p className="eyebrow">The mechanism</p>
            <h2>One patient. One connected revenue journey.</h2>
            <p className="lead">
              More traffic cannot repair a broken journey. The Aesthetic Revenue Loop
              strengthens every step from first attention to a patient who returns and refers.
            </p>
          </div>

          <div className="loop-grid">
            {loop.map(([number, title, body]) => (
              <article key={number}>
                <span>{number}</span>
                <h3>{title}</h3>
                <p>{body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section system-section">
        <div className="shell system-grid">
          <div className="system-intro">
            <p className="eyebrow">What AestheticBiz builds</p>
            <h2>Not another website to admire. A system the practice can use.</h2>
            <p>
              The website is one part. The commercial value comes from how the
              complete journey works together—and how clearly the owner can see it.
            </p>
            <a className="text-link" href="#partnership">See the partnership <span aria-hidden="true">↓</span></a>
          </div>

          <div className="system-list">
            {systemItems.map((item, index) => (
              <article key={item.title}>
                <span>0{index + 1}</span>
                <div><h3>{item.title}</h3><p>{item.body}</p></div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section founder-section" id="founder">
        <div className="shell founder-grid">
          <figure className="founder-portrait">
            <Image
              src="/ignatius-ackermann.webp"
              alt="Ignatius Ackermann, founder of AestheticBiz"
              width={1000}
              height={1000}
              sizes="(max-width: 960px) 100vw, 46vw"
              unoptimized
            />
            <figcaption>Ignatius Ackermann · Founder, AestheticBiz</figcaption>
          </figure>

          <div className="founder-copy">
            <p className="eyebrow">Why founder-led matters</p>
            <h2>No junior handoff after the sale.</h2>
            <p className="founder-lead">
              Ignatius Ackermann has built commercial digital platforms across
              changing technologies and business models since 2001.
            </p>
            <p>
              He remains directly involved from diagnosis and strategy through
              architecture, build and measurement—so the person who understands
              the commercial problem is still there when the system goes live.
            </p>
            <div className="founder-principles" aria-label="Working principles">
              <span>Business model before feature list</span>
              <span>Evidence before claims</span>
              <span>Patient journey before page decoration</span>
            </div>
            <a className="text-link" href="https://www.crmsolutions.app/about" target="_blank" rel="noreferrer">
              Meet Ignatius <span aria-hidden="true">↗</span>
            </a>
          </div>
        </div>
      </section>

      <section className="section proof-section" id="proof">
        <div className="shell proof-grid">
          <div>
            <p className="eyebrow">Evidence before claims</p>
            <h2>Built around a real aesthetic practice.</h2>
          </div>
          <article className="proof-card">
            <a className="proof-image-link" href="https://www.staraesthetic.co.za" target="_blank" rel="noreferrer" aria-label="Visit the Star Aesthetic Centre website">
              <Image
                className="proof-image"
                src="/star-aesthetic-hero.webp"
                alt="Star Aesthetic Centre website hero section"
                width={1350}
                height={606}
                sizes="(max-width: 960px) 100vw, 58vw"
                unoptimized
              />
            </a>
            <div className="proof-card-copy">
            <div className="proof-topline">
              <span>Doctor-led aesthetic clinic · Durban North</span>
              <span>Live platform</span>
            </div>
            <h3>Star Aesthetic Centre</h3>
            <p>
              A premium treatment platform that turns complex choices into a calm,
              credible consultation journey—with original treatment content, clearer
              pathways and visible clinical leadership.
            </p>
            <a href="https://www.staraesthetic.co.za" target="_blank" rel="noreferrer">Visit staraesthetic.co.za <span aria-hidden="true">↗</span></a>
            </div>
          </article>
          <p className="proof-note">
            We show what was built and why. We do not publish revenue claims without
            verified client data and permission.
          </p>
        </div>
      </section>

      <section className="section partnership-section" id="partnership">
        <div className="shell">
          <div className="section-heading split-heading">
            <div>
              <p className="eyebrow">The AestheticBiz Revenue Partnership</p>
              <h2>Diagnose. Build. Improve.</h2>
            </div>
            <p>
              Founder-led from first diagnosis through launch. No page-count package,
              no junior handoff and no disappearing after the site goes live.
            </p>
          </div>

          <div className="partnership-grid">
            <article>
              <span>01 / Diagnose</span>
              <h3>Aesthetic Revenue Leak Audit</h3>
              <p>Map the current patient journey, establish the available numbers and identify the most expensive likely constraint.</p>
            </article>
            <article>
              <span>02 / Build</span>
              <h3>Connected Revenue Platform</h3>
              <p>Design and connect the patient-facing website, decision journeys, booking, follow-through and measurement around the practice.</p>
            </article>
            <article>
              <span>03 / Improve</span>
              <h3>90-Day Launch Support</h3>
              <p>Validate the live journey, resolve platform defects, read early performance signals and prioritise the next commercial improvement.</p>
            </article>
          </div>

          <div className="investment-row">
            <div>
              <span>AestheticBiz Revenue Platform</span>
              <strong>From US$10,000</strong>
              <small>50% deposit · 50% upon completion, before launch</small>
            </div>
            <p>Final investment follows the practice, the patient journeys, integrations and the value of the constraint—not an arbitrary number of pages.</p>
          </div>
        </div>
      </section>

      <section className="section faq-section">
        <div className="shell faq-grid">
          <div>
            <p className="eyebrow">Before you ask</p>
            <h2>The questions practice owners actually ask.</h2>
          </div>
          <div className="faq-list">
            <Faq question="My booking platform already sends reminders. Is this still relevant?" answer="Yes. A reminder is one step. We examine what happens before the booking, how quickly an enquiry is acknowledged, what builds trust, what happens after treatment and whether the owner can see the whole journey." />
            <Faq question="Do I have to replace my current practice software?" answer="Not automatically. AestheticBiz is designed around the practice you already run. We first determine what should stay, what can connect and where replacement would genuinely create value." />
            <Faq question="Are you guaranteeing that patients will return?" answer="No. Patient choices and clinical suitability cannot be guaranteed. We commit to the agreed scope, clear milestones, thorough testing and correcting agreed deliverables that do not meet the approved specification." />
            <Faq question="Is this only for large, multi-location med spas?" answer="No. It is designed primarily for established, owner-led aesthetic practices with proven demand, a credible clinical offer and a patient journey that is not yet working as one measurable system." />
          </div>
        </div>
      </section>

      <section className="section final-cta">
        <div className="shell final-cta-inner">
          <p className="eyebrow">A focused commercial conversation</p>
          <h2>You have already done the hard work of earning the first visit.</h2>
          <p>Let’s examine what would make more of those patient relationships continue.</p>
          <a className="button button-primary" href="https://www.aestheticbiz.site/book-discovery">Book a Discovery Call <span aria-hidden="true">↗</span></a>
          <small>If the economics do not justify a US$10,000+ engagement, Ignatius will say so.</small>
        </div>
      </section>

      <footer>
        <div className="shell footer-grid">
          <div>
            <a className="brand" href="#top" aria-label="AestheticBiz home">
              <Image className="brand-logo footer-logo" src="/aestheticbiz-logo-transparent.png" alt="Aesthetic Biz — Aesthetic and Wellness" width={1456} height={343} unoptimized />
            </a>
            <p>A specialised aesthetic-practice initiative by CRM Solutions.</p>
          </div>
          <div>
            <span>Built for the long term</span>
            <p>Founder-led from Durban, South Africa. Working remotely with established US practices.</p>
          </div>
          <div>
            <span>Next step</span>
            <a href="https://www.aestheticbiz.site/book-discovery">Book a Discovery Call ↗</a>
          </div>
        </div>
        <div className="shell footer-bottom">
          <span>© 2026 CRM Solutions. All rights reserved.</span>
          <span>Evidence before claims · Patient journey before feature list</span>
        </div>
      </footer>
    </main>
  );
}

function Slider({ label, value, min, max, step, display, onChange }: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  display: string;
  onChange: (value: number) => void;
}) {
  const progress = ((value - min) / (max - min)) * 100;
  const percentUnit = label.includes("rate") || label.includes("return") || label.includes("margin");

  return (
    <label className="slider-row">
      <span className="slider-label"><span>{label}</span><strong>{display}</strong></span>
      <input type="range" value={value} min={min} max={max} step={step} onChange={(event) => onChange(Number(event.target.value))} style={{ "--progress": `${progress}%` } as React.CSSProperties} aria-label={label} />
      <span className="slider-range"><small>{min}{percentUnit ? "%" : ""}</small><small>{max}{percentUnit ? "%" : ""}</small></span>
    </label>
  );
}

function Faq({ question, answer }: { question: string; answer: string }) {
  return (
    <details>
      <summary>{question}<span aria-hidden="true">+</span></summary>
      <p>{answer}</p>
    </details>
  );
}
