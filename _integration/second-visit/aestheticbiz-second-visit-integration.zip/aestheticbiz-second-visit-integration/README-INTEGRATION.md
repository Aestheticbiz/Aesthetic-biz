# AestheticBiz “Second Visit” integration package

This package contains the current source and production assets for the approved
“Second Visit” landing page.

## Target project

`C:\Users\ignat\Local Sites\aestheticbiz`

## Important integration rule

Do **not** overwrite the existing website homepage, root layout, or global
stylesheet with these reference files.

The local coding agent should first inspect the existing Next.js project and
then merge this design into the route:

`/second-visit`

Recommended target file:

`app/second-visit/page.tsx`

## Integration work

1. Use `reference/app/page.tsx` as the approved page implementation.
2. Adapt and scope `reference/app/globals.css` so it cannot alter other pages.
3. Copy the four files in `reference/public/` into the existing project's
   `public/` directory without replacing unrelated assets.
4. Merge only the required metadata or favicon changes from
   `reference/app/layout.tsx`; do not replace the existing root layout.
5. Keep all “Book a Discovery Call” links pointed to:
   `https://www.aestheticbiz.site/book-discovery`
6. Preserve the existing website navigation, shared components, analytics,
   fonts, SEO conventions, and deployment configuration.
7. Run the existing lint/build checks and verify `/second-visit` on desktop and
   mobile before committing.

## Approved visual reference

https://aestheticbiz-second-visit.ignatiusack.chatgpt.site

